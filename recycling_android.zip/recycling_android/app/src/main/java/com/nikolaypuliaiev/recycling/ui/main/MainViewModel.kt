package com.nikolaypuliaiev.recycling.ui.main

import com.nikolaypuliaiev.recycling.utils.BaseClasses.BaseViewModel

class MainViewModel: BaseViewModel() {

    private val TAG: String = MainViewModel::class.java.simpleName
}