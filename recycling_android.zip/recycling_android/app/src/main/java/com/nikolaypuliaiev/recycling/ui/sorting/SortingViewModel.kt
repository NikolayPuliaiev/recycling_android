package com.nikolaypuliaiev.recycling.ui.sorting

import com.nikolaypuliaiev.recycling.utils.BaseClasses.BaseViewModel

class SortingViewModel: BaseViewModel() {

}