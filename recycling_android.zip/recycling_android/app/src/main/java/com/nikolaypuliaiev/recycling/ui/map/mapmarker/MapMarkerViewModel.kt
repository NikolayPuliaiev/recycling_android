package com.nikolaypuliaiev.recycling.ui.map.mapmarker

import com.nikolaypuliaiev.recycling.utils.BaseClasses.BaseViewModel

class MapMarkerViewModel: BaseViewModel() {

}