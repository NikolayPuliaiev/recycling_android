package com.nikolaypuliaiev.recycling.ui.favorite

import com.nikolaypuliaiev.recycling.utils.BaseClasses.BaseViewModel

class FavoriteViewModel: BaseViewModel() {

}