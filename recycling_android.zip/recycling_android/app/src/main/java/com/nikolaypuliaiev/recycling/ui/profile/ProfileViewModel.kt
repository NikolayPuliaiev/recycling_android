package com.nikolaypuliaiev.recycling.ui.profile

import com.nikolaypuliaiev.recycling.utils.BaseClasses.BaseViewModel

class ProfileViewModel: BaseViewModel() {

}